#include <math.h>
#include <stdio.h>

float max(float a);

int main() {
    float x;
    printf("Введите число: ");
    if (scanf("%f", &x) != 1) {
        printf("n/a\n");
        return 1;
    } else {
        printf("%.1f\n", max(x));
    }
    return 0;
}

float max(float a) {
    return (7E-3 * pow(a, 4) + ((22.8 * pow(a, (1 / 3)) - 1E3) * a + 3) / (a * a / 2) -
            a * pow((10 + a), (2 / a)) - 1.01);
}