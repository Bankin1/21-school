#include <math.h>
#include <stdio.h>

float check(float a, float b);

int main() {
    float x, y;
    if (scanf("%f %f", &x, &y) != 2) {
        printf("n/a\n");
    } else {
        if (check(x, y) <= 25) {
            printf("GOTCA\n");
        } else {
            printf("MISS\n");
        }
    }
}

float check(float a, float b) { return pow(a, 2) + pow(b, 2); }