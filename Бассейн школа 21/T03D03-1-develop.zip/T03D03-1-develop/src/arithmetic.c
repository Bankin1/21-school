
#include <stdio.h>

int sum(int a, int b);

int unsum(int a, int b);

int mnoz(int a, int b);

int del(int a, int b);

int main() {
    int x, y;
    printf("Введите два целых числа: ");
    if (scanf("%d %d", &x, &y) == 2 && getchar() == '\n') {
        if (y == 0) {
            printf("%d %d %d n/a\n", sum(x, y), unsum(x, y), mnoz(x, y));
        } else {
            printf("%d %d %d %d\n", sum(x, y), unsum(x, y), mnoz(x, y), del(x, y));
        }
    } else {
        printf("n/a");
        return 1;
    }
    return 0;
}

int sum(int a, int b) { return (a + b); }
int unsum(int a, int b) { return (a - b); }
int mnoz(int a, int b) { return (a * b); }
int del(int a, int b) { return (a / b); }
