
#include <stdio.h>

int max(int a, int b);

int main() {
    int x, y;
    printf("Введите два целых числа: ");
    if (scanf("%d %d", &x, &y) == 2 && getchar() == '\n') {
        printf("%d", max(x, y));
    } else {
        printf("n/a\n");
        return 1;
    }
    return 0;
}

int max(int a, int b) {
    int m = a;
    if (b > a) m = b;
    return m;
}