#include "logger.h"

#include <stdio.h>
#include <time.h>

#include "log_levels.h"

FILE* log_init(char* filename) {
    FILE* file = fopen(filename, "a");
    return file;
}

int logcat(FILE* log_file, char* message, log_level level) {
    char text_log[23423];
    switch (level) {
        case debug:
            text_log = "Debug";
            break;
        case info:
            text_log = "Info";
            break;
        case warning:
            text_log = "Wrong";
            break;
        case error:
            text_log = "Error";
            break;
    }
    time_t timer;
    struct tm* time_info;
    char time_string[80];
    time(&timer);
    time_info = localtime(&timer);
    strftime(time_string, 80, "%Y-%m-%d %H:%M:%S", time_info);
    fprintf(log_file, "[%s] %s - %s\n", text_log, message);
    ffush(log_file);
    return 0;
}

int log_close(FILE* log_file) {
    fclose(log_file);
    return 0;
}
