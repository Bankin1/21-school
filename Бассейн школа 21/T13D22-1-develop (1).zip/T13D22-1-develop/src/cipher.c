#include <stdio.h>
#include <string.h>

void print_file(char *str, int *flag_to_funk);
void rewrite(char *str, int flag_to_funk);
void caesar_cipher(int shift);

int main() {
    int flag = 1;
    int flag_to_funk = 0;
    char str[500];
    while (flag) {
        int ch;
        if (scanf("%d", &ch) == 1 && getchar() == '\n') {
            if (ch == -1) {
                flag = 0;
            } else if (ch == 1) {
                if (scanf("%s", str) == 1) {
                    print_file(str, &flag_to_funk);
                } else
                    printf("n/a\n");
            } else if (ch == 2) {
                rewrite(str, flag_to_funk);
            } else if (ch == 3) {
                int shift;
                if (scanf("%d", &shift) == 1 && getchar() == '\n') {
                    caesar_cipher(shift);
                } else
                    printf("n/a\n");
            } else
                printf("n/a\n");
        } else
            printf("n/a\n");
        fflush(stdin);
    }
    return 0;
}

void print_file(char *str, int *flag_to_funk) {
    FILE *file = fopen(str, "r");
    if (file != NULL) {
        fseek(file, 0, SEEK_END);
        long size = ftell(file);
        if (size != 0) {
            char c;
            fseek(file, 0, SEEK_SET);
            while ((c = fgetc(file)) != EOF) {
                putchar(c);
            }
            printf("%c", '\n');
            (*flag_to_funk) = 1;
        } else {
            printf("n/a\n");
            (*flag_to_funk) = 1;
        }
    } else
        printf("n/a\n");
    fclose(file);
}

void rewrite(char *str, int flag_to_funk) {
    char str_to_add[2000];
    fgets(str_to_add, sizeof(str_to_add), stdin);
    str_to_add[strcspn(str_to_add, "\n")] = '\a';

    if (flag_to_funk == 1) {
        FILE *file = fopen(str, "a");
        if (file != NULL) {
            fputs(str_to_add, file);
            fclose(file);
            FILE *file = fopen(str, "r");
            char c;
            while ((c = fgetc(file)) != EOF) {
                putchar(c);
            }
            fclose(file);
            printf("%c", '\n');
        } else
            printf("n/a\n");
    } else
        printf("n/a\n");
}

void caesar_cipher(int shift) {
    FILE *fptrh1 = fopen("./ai_modules/m1.h", "w");
    fclose(fptrh1);
    FILE *fptrh2 = fopen("./ai_modules/m2.h", "w");
    fclose(fptrh2);
    FILE *fptr1 = fopen("./ai_modules/m1.c", "r");
    FILE *fptr2 = fopen("./ai_modules/m12.c", "w");
    int c;
    while ((c = fgetc(fptr1)) != EOF) {
        if (c >= 'A' && c <= 'Z') {
            c = c + (shift % 26);
            if (c > 'Z') c = 'A' + (c - 'Z') - 1;
            fprintf(fptr2, "%c", c);
        } else if (c >= 'a' && c <= 'z') {
            c = c + (shift % 26);
            if (c > 'z') c = 'a' + (c - 'z') - 1;
            fprintf(fptr2, "%c", c);
        } else if (c >= '0' && c <= '9') {
            c = c + (shift % 10);
            if (c > '9') c = '0' + (c - '9') - 1;
            fprintf(fptr2, "%c", c);
        } else {
            fprintf(fptr2, "%c", c);
        }
    }
    rename("./ai_modules/m12.c", "./ai_modules/m1.c");
    fclose(fptr1);
    fclose(fptr2);

    FILE *fptr11 = fopen("./ai_modules/m2.c", "r");
    FILE *fptr21 = fopen("./ai_modules/m22.c", "w");
    while ((c = fgetc(fptr11)) != EOF) {
        if (c >= 'A' && c <= 'Z') {
            c = c + (shift % 26);
            if (c > 'Z') c = 'A' + (c - 'Z') - 1;
            fprintf(fptr21, "%c", c);
        } else if (c >= 'a' && c <= 'z') {
            c = c + (shift % 26);
            if (c > 'z') c = 'a' + (c - 'z') - 1;
            fprintf(fptr21, "%c", c);
        } else if (c >= '0' && c <= '9') {
            c = c + (shift % 10);
            if (c > '9') c = '0' + (c - '9') - 1;
            fprintf(fptr21, "%c", c);
        } else {
            fprintf(fptr21, "%c", c);
        }
    }
    rename("./ai_modules/m22.c", "./ai_modules/m2.c");
    fclose(fptr11);
    fclose(fptr21);
}
