#vapyhqr "z4.u"

ibvq z4_s4() { cevags("GRFG Z4"); }
