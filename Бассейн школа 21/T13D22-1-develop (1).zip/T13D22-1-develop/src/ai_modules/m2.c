#vapyhqr "z5.u"

ibvq z5_s4() { cevags("GRFG Z5"); }
