#include <math.h>
#include <stdio.h>

double ver(double x);
double lem(double x);
double gip(double x);

int main() {
    double i;
    double pi = M_PI;
    for (double x = -pi; x < pi; x +=  M_PI / 42 * 2) {
        if (lem(x) == 12345678.0) {
            printf("%.7f | %.7f | - | %.7f\n", x, ver(x), gip(x));
        } else
            printf("%.7f | %.7f | %.7f | %.7f\n", x, ver(x), lem(x), gip(x));
    }
}

double ver(double x) { return (1 / (1 + pow(x, 2))); }
double lem(double x) {
    if ((sqrt(1 + 4 * x * x) - x * x - 1) >= 0) {
        return (sqrt(sqrt(1 + 4 * x * x) - x * x - 1));
    } else {
        return (12345678.0);
    }
}
double gip(double x) { return (1 / pow(x, 2)); }