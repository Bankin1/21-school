#include <math.h>
#include <stdio.h>

int fib(int x);

int main() {
    int x;
    if ((scanf("%d", &x) == 1 && getchar() == '\n')) {
        if (x >= 0)
            printf("%d\n", fib(x));
        else
            printf("n/a\n");
    } else {
        printf("n/a\n");
    }
}

int fib(int x) {
    if (x == 0 || x == 1) return x;
    return fib(x - 1) + fib(x - 2);
}