#include <math.h>
#include <stdio.h>

int simp(int a);
int big(int a);

int main() {
    int x;
    if (scanf("%d", &x) != 1 || getchar() != '\n') {
        printf("n/a\n");

    } else {
        if (x == 0) {
            printf("n/a\n");
        } else {
            printf("%d\n", big(x));
        }
    }
}

int simp(int a) {
    int k, c, s;
    k = 0;
    if (a > 0) {
        for (int b = 2; b < a; b++) {
            c = a;
            s = 0;
            while (c > 0) {
                c = a;
                c = c - b * s;
                s++;
                if (c == 0) k++;
            }
            if (k != 0) {
                return (0);
            }
        }
        if (k == 0) {
            return (1);
        }
    } else
        printf("n/a\n");
    return 0;
}
int big(int a) {
    int b, s, k;
    float d = a;
    k = 0;
    int c = fabsf(d);
    if (a == 1) return (a);
    for (int i = c - 1; i > 1; i--) {
        b = c;
        s = 0;

        if (simp(i) == 1) {
            while (b > 0) {
                b = c;
                b = b - i * s;
                s++;
                if (b == 0) {
                    return (i);
                    k++;
                    break;
                }
            }
        }
    }
    if (k == 0) return (1);
    return 0;
}
