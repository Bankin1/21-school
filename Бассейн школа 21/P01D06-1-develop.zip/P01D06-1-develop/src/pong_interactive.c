//
// Created by Kimiko Dornish on 9/3/23.
//
#include <ncurses.h>

#define WIDTH 80
#define HEIGHT 25

struct points {
    int first;
    int second;
};

struct point {
    int x;
    int y;
};

void table(struct point rocket_l, struct point rocket_r, struct point ball, struct points score);
void txt_hello();
void txt_end(struct points score);
void move_ball(struct point ball, struct point step);
void move_rocket(struct point rocket, int rocket_step);
void c_ball(struct point *ball, struct point *step, struct point rocket_l, struct point rocket_r);
void c_rocket(struct point *rocket, int step);
int check_collision(struct point ball, struct point rocket_l, struct point rocket_r);
int c_score(struct point ball, struct points *score);

int main() {
    if (!(initscr())) {
        fprintf(stderr, "type: initscr() failed\n\n");
        return 1;
    }
    if ((LINES < HEIGHT) || (COLS < WIDTH)) {
        fprintf(stderr, "screen too small\n\n");
        endwin();
        return 1;
    }

    struct point ball = {40, 12}, step = {2, 1}, rocket_l = {3, 12}, rocket_r = {77, 12};
    struct points score = {0, 0};
    int rocket_step = 1, end_score = 21;
    noecho();
    txt_hello();
    clear();
    table(rocket_l, rocket_r, ball, score);
    while (score.first != end_score && score.second != end_score) {
        int ch;
        timeout(70);
        ch = getch();
        switch (ch) {
            case 'A': {
                c_rocket(&rocket_l, rocket_step);
                // move_rocket(rocket_l, rocket_step);
                break;
            }
            case 'Z': {
                c_rocket(&rocket_l, -rocket_step);
                // move_rocket(rocket_l, -rocket_step);
                break;
            }
            case 'K': {
                c_rocket(&rocket_r, rocket_step);
                // move_rocket(rocket_r, rocket_step);
                break;
            }
            case 'M': {
                c_rocket(&rocket_r, -rocket_step);
                // move_rocket(rocket_r, -rocket_step);
                break;
            }
            default: {
                break;
            }
        }
        c_ball(&ball, &step, rocket_l, rocket_r);
        if (c_score(ball, &score)) {
            ball.x = 40;
            ball.y = 12;
            rocket_r.y = 12;
            rocket_l.y = 12;
        }
        // move_ball(ball, step);
        clear();
        table(rocket_l, rocket_r, ball, score);
    }
    clear();
    txt_end(score);
    refresh();
    return 0;
}

// void move_ball(struct point ball, struct point step) {
//   mvwdelch(stdscr, ball.y - step.y, ball.x - step.x);
//   mvwinsch(stdscr, ball.y - step.y, ball.x - step.x, ' ');
//   mvwdelch(stdscr, ball.y, ball.x);
//   mvwinsch(stdscr, ball.y , ball.x, 'o');
// }

// void move_rocket(struct point rocket, int rocket_step) {
//   if (rocket_step > 0) {
// 	mvwdelch(stdscr, rocket.y - 2, rocket.x);
// 	mvwinsch(stdscr, rocket.y - 2, rocket.x, ' ');
// 	mvwdelch(stdscr, rocket.y + 1, rocket.x);
// 	mvwinsch(stdscr, rocket.y + 1, rocket.x, '|');
//   } else if (rocket_step < 0) {
// 	mvwdelch(stdscr, rocket.y + 2, rocket.x);
// 	mvwinsch(stdscr, rocket.y + 2, rocket.x, ' ');
// 	mvwdelch(stdscr, rocket.y - 1, rocket.x);
// 	mvwinsch(stdscr, rocket.y - 1, rocket.x, '|');
//   }
// }

int c_score(struct point ball, struct points *score) {
    int k = 0;  // если 'k' изменяется, то выводится 1 для проверки на изменение
    // счета (обнуление для того чтобы проверка работала каждый раз)

    if (ball.x <= 3) {      // проверка на гол в левые ворота
        (score->second)++;  // изменение счета правого игрока
        k++;                // 'k' изменяется если увеличивается счет
    } else if (ball.x >= WIDTH - 2) {  //прверка на гол в правые ворота
        (score->first)++;              // изменение счета правого игрока
        k++;
    }

    return k;  //  счет правого игрока закодирован перемножением на
               //  1000000, левого на 10000, счетчик 'k' последний символ
}

void table(struct point rocket_l, struct point rocket_r, struct point ball, struct points score) {
    printw("\t\t\tPlayer 1: %d\t|\tPlayer 2: %d\n", score.first, score.second);
    for (int height = 1; height <= HEIGHT; height++) {  // высота поля
        for (int width = 1; width <= WIDTH; width++) {  // ширина поля
            if (height == 1 || height == HEIGHT) {  // проставляем символы по ширине поля
                mvwinsch(stdscr, height, width, '-');
            } else if (((height == rocket_l.y || height == rocket_l.y + 1 || height == rocket_l.y - 1) &&
                        width == 3) ||
                       // выставляем левую ракетку
                       ((height == rocket_r.y || height == rocket_r.y + 1 || height == rocket_r.y - 1) &&
                        width == WIDTH - 3)) {  // выставляем правую ракетку
                mvwinsch(stdscr, height, width, '|');
            } else if (ball.y == height && ball.x == width) {  // проставляем шарик
                mvwinsch(stdscr, height, width, 'o');
            } else if (width == 1 || width == WIDTH - 1 || width == 40) {  // проставляем боковые границы поля
                mvwinsch(stdscr, height, width, '|');
            } else {
                mvwinsch(stdscr, height, width, ' ');
            }
        }
    }
}

void txt_hello() {
    printw("\t\tHello friend! We want to offer you to play PONG!\n");
    printw("\t   A game for two! The winner is the one who scores 21 points!\n");
    printw("\t\t  Keyboard commands that will be useful to you:\n");
    printw(
        "  For Player 1: 'A' - the racket moves up / 'Z' - the racket moves "
        "down\n");
    printw("\tFor Player 2: 'K' - racket moves up / 'M' - racket moves down\n");
    printw("\t\t\t  'SPACE' - to skip an action'\n");
    printw("\t\t\t   To start, press any key...\n");

    while (1) {
        char key = getch();
        if (key == '\n' || key == '\r') {
            continue;
        }
        break;
    }
}

void txt_end(struct points score) {
    if (score.first == 21) {
        printw("\t\t\tPlayer 1 WIN! Congratulations!\n");
    } else if (score.second == 21) {
        printw("\t\t\tPlayer 2 WIN! Congratulations!\n");
    }
}

void c_rocket(struct point *rocket, int step) {
    if (!((*rocket).y <= 2 && step > 0) &&
        !((*rocket).y >= HEIGHT - 3 && step < 0)) {  // проверяем не стоит ли ракетка возле верхней границы
        (*rocket).y -= step;  // если стоит вплотную и координата изменяется в сорону
                              // границы, то ракетка остается на месте
    }  // в иных случаях координата изменяется на координату 'change'
}
void c_ball(struct point *ball, struct point *step, struct point rocket_l, struct point rocket_r) {
    if (check_collision((*ball), rocket_l,
                        rocket_r)) {  //проверяем на сталкновение с ракеткой и
        //сближением с правым краем
        (*step).x = -(*step).x;
    }
    if ((*ball).y <= 2 || (*ball).y >= HEIGHT - 1) {
        (*step).y = -(*step).y;
    }
    (*ball).x += (*step).x;
    (*ball).y += (*step).y;
}

int check_collision(struct point ball, struct point rocket_l, struct point rocket_r) {
    int check = 0;

    if (((ball.x >= WIDTH - 4) &&
         (rocket_r.y == ball.y || rocket_r.y + 1 == ball.y || rocket_r.y - 1 == ball.y)) ||
        ((ball.x <= 5) && (rocket_l.y + 1 == ball.y || rocket_l.y - 1 == ball.y || rocket_l.y == ball.y))) {
        check = 1;
    }
    return check;
}
