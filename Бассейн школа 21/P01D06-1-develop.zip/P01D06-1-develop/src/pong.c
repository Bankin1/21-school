// I WANT TO PLAY WITH YOU
//         YOUR FRIEND, AI

/*
 * Игра Понг
 * */

#include <stdio.h>

// функция отрисовки поля
void table(int rocket_l, int rocket_r, int ball_x, int ball_y, int HEIGHT,
           int WEIGHT, int score_l, int score_r);
// функция приветствия
void txt_hello();
// функция смены положения ракетки
int c_rocket(int rocket_y, int change, int HEIGHT);
// функция начисления очков
int score(int ball_x, int score_l, int score_r, int WEIGHT);
//функция очистки экрана
void clear();
// int c_ball(int ball_x, int ball_y, int rocket_r, int rocket_l, int step_x,
// int step_y, int HEIGHT, int WEIGHT);
int check_collision(int ball_x, int ball_y, int rocket_r, int rocket_l,
                    int WEIGHT);
// Завершающий текст
void txt_end(int score_l, int score_r);

int main() {
  const int HEIGHT = 25;
  const int WEIGHT = 80;
  int rocket_l = 13, rocket_r = 13, score_l = 0, score_r = 0,
      ball_x = WEIGHT / 2, ball_y = HEIGHT / 2, step_x = 2, step_y = 1;

  txt_hello();
  clear();
  table(rocket_l, rocket_r, ball_x, ball_y, HEIGHT, WEIGHT, 0, 0);
  // пока ни один из игроков не достиг счета 21
  while (score_l != 21 && score_r != 21) {
    char a;
    // получения команды из консоли
    a = getchar();
    // смена положения ракетки
    if (a == 'A') {
      rocket_l = c_rocket(rocket_l, 1, HEIGHT);
    } else if (a == 'Z') {
      rocket_l = c_rocket(rocket_l, -1, HEIGHT);
    } else if (a == 'K') {
      rocket_r = c_rocket(rocket_r, 1, HEIGHT);
    } else if (a == 'M') {
      rocket_r = c_rocket(rocket_r, -1, HEIGHT);
    }
    if (a == ' ' || a == 'A' || a == 'Z' || a == 'K' || a == 'M') {
      // изменение всего поля
      // очистка старых данных
      clear();
      // проверка на изменение очков
      // в случае удачной проверки положения мяча и ракеток обнуляется
      int res = score(ball_x, score_l, score_r, WEIGHT);
      int flag = res % 10;

      score_l = (res / 10000) % 100;
      score_r = (res / 1000000) % 100;

      if (flag) {
        ball_x = WEIGHT / 2 - step_x;
        ball_y = HEIGHT / 2 - step_y;
        rocket_l = 13;
        rocket_r = 13;
      }
      if (check_collision(ball_x, ball_y, rocket_r, rocket_l,
                          WEIGHT)) { //проверяем на сталкновение с ракеткой и
                                     //сближением с правым краем
        step_x = -step_x;
      }
      if (ball_y <= 1 || ball_y >= HEIGHT - 2) {
        step_y = -step_y;
      }
      ball_x += step_x;
      ball_y += step_y;
      // отрисовка нового поля
      table(rocket_l, rocket_r, ball_x, ball_y, HEIGHT, WEIGHT, score_l,
            score_r);
    }
  }
  txt_end(score_l, score_r);
  return 0;
}

// void clear() { printf("\033[H\033[J"); }

void clear() { printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"); }

//функция для измененя координаты рокетки
int c_rocket(int rocket_y, int change, int HEIGHT) {
  if (!(rocket_y <= 2 && change > 0) &&
      !(rocket_y >= HEIGHT - 3 &&
        change < 0)) { // проверяем не стоит ли ракетка возле верхней границы
    rocket_y -= change; // если стоит вплотную и координата изменяется в сорону
                        // границы, то ракетка остается на месте
  } // в иных случаях координата изменяется на координату 'change'
  return rocket_y;
}
int score(int ball_x, int score_l, int score_r, int WEIGHT) {
  int k = 0; // если 'k' изменяется, то выводится 1 для проверки на изменение
             // счета (обнуление для того чтобы проверка работала каждый раз)

  if (ball_x <= 3) { // проверка на гол в левые ворота
    score_r++; // изменение счета правого игрока
    k++; // 'k' изменяется если увеличивается счет
  } else if (ball_x >= WEIGHT - 2) { //прверка на гол в правые ворота
    score_l++; // изменение счета правого игрока
    k++;
  }
  int res_score = score_r * 1000000 + score_l * 10000 + k;

  return res_score; //  счет правого игрока закодирован перемножением на
                    //  1000000, левого на 10000, счетчик 'k' последний символ
}

void table(int rocket_l, int rocket_r, int ball_x, int ball_y, int HEIGHT,
           int WEIGHT, int score_l, int score_r) {
  printf("\t\t\tPlayer 1: %d\t|\tPlayer 2: %d\n", score_l, score_r);
  for (int height = 0; height < HEIGHT; height++) { // высота поля
    for (int width = 0; width < WEIGHT; width++) {  // ширина поля
      if (height == 0 ||
          height == HEIGHT - 1) { // проставляем символы по ширине поля
        putchar('-');
      } else if (((height == rocket_l || height == rocket_l + 1 ||
                   height == rocket_l - 1) &&
                  width == 3) || // выставляем левую ракетку
                 ((height == rocket_r || height == rocket_r + 1 ||
                   height == rocket_r - 1) &&
                  width == WEIGHT - 3)) { // выставляем правую ракетку
        printf("|");
      } else if (ball_y == height && ball_x == width) { // проставляем шарик
        printf("o");
      } else if (width == 0 || width == WEIGHT - 1 ||
                 width == 40) { // проставляем боковые границы поля
        printf("|");
      } else {
        printf(" ");
      }
    }
    printf("\n");
  }
}

void txt_hello() {
  printf("\t\tПривет друг! Мы хотим тебе предложить сыграть в PONG!\n");
  printf("\t\t   Игра для двоих! Победит тот кто наберет 21 очко!\n");
  printf("\t\t    Команды на клавиатуре которые тебе пригодятся:\n");
  printf("\tДля Player 1: 'A' - ракетка двигается вверх / 'Z' - ракетка "
         "двигается вниз\n");
  printf("\tДля Player 2: 'K' - ракетка двигается вверх / 'M' - ракетка "
         "двигается вниз\n");
  printf("\t\t\t  'SPACE' - для пропуска действия'\n");
  printf("\t\tДля старта введите любой символ и нажмите 'Enter'...\n");

  while (1) {
    char key = getchar();

    if (key == '\n' || key == '\r') {
      continue;
    }
    break;
  }
}

void txt_end(int score_l, int score_r) {

  if (score_l == 21) {
    printf("\t\t\tPlayer 1 Победил! Поздравляем!\n");
  } else if (score_r == 21) {
    printf("\t\t\tPlayer 2 Победил! Поздравляем!\n");
  }
}

int check_collision(int ball_x, int ball_y, int rocket_r, int rocket_l,
                    int WEIGHT) {
  int check = 0;

  if (((ball_x >= WEIGHT - 4) &&
       (rocket_r == ball_y || rocket_r + 1 == ball_y ||
        rocket_r - 1 == ball_y)) ||
      ((ball_x <= 5) && (rocket_l + 1 == ball_y || rocket_l - 1 == ball_y ||
                         rocket_l == ball_y))) {
    check = 1;
  }
  return check;
}
