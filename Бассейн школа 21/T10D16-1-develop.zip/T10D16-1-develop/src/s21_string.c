#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

int s21_strlen(const char *str) {
    int lensth = 0;
    while (str[lensth] != 0) lensth++;
    return lensth;
}

int s21_strcmp(char *str1, char *str2) {
    for (; *(str1) && *str1 == *str2; str1++, str2++)
        ;
    return *str1 - *str2;
}

char *s21_strcpy(char *str2, const char *str1) {
    if (str2 == NULL) {
        return NULL;
    }
    for (int i = 0; (str2[i] = str1[i]) != '\0'; i++) {
    }
    return str2;
}

char *s21_strcat(char *str1, char *str2) {
    if (str1 == NULL) {
        return NULL;
    }
    char *prt = str1;
    int lenght = s21_strlen(str1);
    for (; *str2; lenght++, str2++) {
        str1[lenght] = *str2;
    }
    str1[lenght] = '\0';
    return prt;
}

int s21_strchr(const char *str, char ch) {
    if (str == NULL) {
        return 0;
    }
    int lensth = 0;
    while (str[lensth] != 0) {
        if (str[lensth] == ch) {
            return lensth;
        }
        lensth++;
    }
    return 0;
}

int compare(const char *str1, const char *str2) {
    while (*str1 && *str2) {
        if (*str1 != *str2) {
            return 0;
        }

        str1++;
        str2++;
    }

    return (*str2 == '\0');
}

char *s21_strstr(char *str1, char *str2) {
    while (*str1 != '\0') {
        if ((*str1 == *str2) && compare(str1, str2)) {
            return str1;
        }
        str1++;
    }
    return NULL;
}