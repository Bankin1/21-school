#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

#include "s21_string_test.h"

int main() {
#ifdef STRLEN
    s21_strlen_test();
#endif
#ifdef STRCMP
    s21_strcmp_test();
#endif
#ifdef STRCPY
    s21_strcpy_test();
#endif
#ifdef STRCAT
    s21_strcat_test();
#endif
#ifdef STRCHR
    s21_strchr_test();
#endif
#ifdef STRSTR
    s21_strstr_test();
#endif
    return 0;
}

void s21_strlen_test() {
    int test = 13;
    char str_test1[] = "Hello, world!";
    int result = s21_strlen(str_test1);
    otput_result_1(str_test1, result, test);
    printf("%c", '\n');
    test = 0;
    char str_test2[] = "";
    result = s21_strlen(str_test2);
    otput_result_1(str_test2, result, test);
    printf("%c", '\n');
    test = 15;
    char str_test3[] = "               ";
    result = s21_strlen(str_test3);
    otput_result_1(str_test3, result, test);
}

void otput_result_1(char *str, int result, int test) {
    printf("%s %d\n", str, result);
    if (result == test) {
        printf("SUCCESS");
    } else
        printf("FAIL");
}

void s21_strcmp_test() {
    char str11[] = "123";
    char str21[] = "123";
    int test = 0;
    int result = s21_strcmp(str11, str21);
    otput_result_2(str11, str21, result, test);
    printf("%c", '\n');
    char str12[] = "";
    char str22[] = "";
    test = 0;
    result = s21_strcmp(str12, str22);
    otput_result_2(str12, str22, result, test);
    printf("%c", '\n');
    char str13[] = "321";
    char str23[] = "123";
    test = 2;
    result = s21_strcmp(str13, str23);
    otput_result_2(str13, str23, result, test);
}

void otput_result_2(char *str1, char *str2, int result, int test) {
    printf("%s\n%s\n%d\n", str1, str2, result);
    if (result * test > 0) {
        printf("SUCCESS");
    } else if (test == 0 && result == 0) {
        printf("SUCCESS");
    } else
        printf("FAIL");
}

void s21_strcpy_test() {
    char str11[] = "123";
    char str_ptint1[50];
    output_result_3(str_ptint1, str11, s21_strcpy(str_ptint1, str11), str11);
    printf("%c", '\n');
    char str12[] = "";
    char str_ptint2[50];
    output_result_3(str_ptint2, str12, s21_strcpy(str_ptint2, str12), str12);
    printf("%c", '\n');
    char str13[] = "KFC burger king ...";
    char str_ptint3[50];
    output_result_3(str_ptint3, str13, s21_strcpy(str_ptint3, str13), str13);
}

void output_result_3(char *str_print, char *str, char *result, char *test) {
    printf("%s\n%s\n", str, result);
    if (s21_strcmp(str_print, test) == 0) {
        printf("SUCCESS");
    } else
        printf("FAIL");
}

void s21_strcat_test() {
    char str11[] = "123";
    char str21[] = "456";
    char test1[] = "123456";
    output_result_4(str21, str11, s21_strcat(str11, str21), test1);
    printf("%c", '\n');
    char str12[] = "";
    char str22[] = "";
    char test2[] = "";
    output_result_4(str22, str12, s21_strcat(str12, str22), test2);
    printf("%c", '\n');
    char str13[] = "der";
    char str23[] = "ham";
    char test3[] = "derham";
    output_result_4(str23, str13, s21_strcat(str13, str23), test3);
}

void output_result_4(char *str_print, char *str, char *result, char *test) {
    printf("%s\n%s\n", str, str_print);
    if (s21_strcmp(result, test) == 0) {
        printf("SUCCESS");
    } else
        printf("FAIL");
}

void s21_strchr_test() {
    char *str1 = "123456";
    char ch1 = '3';
    int test1 = 2;
    output_result_5(ch1, str1, s21_strchr(str1, ch1), test1);
    printf("%c", '\n');
    char *str2 = "";
    char ch2 = '3';
    int test2 = 0;
    output_result_5(ch2, str2, s21_strchr(str2, ch2), test2);
    printf("%c", '\n');
    char *str3 = "1dgdhfg";
    char ch3 = 'g';
    int test3 = 2;
    output_result_5(ch3, str3, s21_strchr(str3, ch3), test3);
    printf("%c", '\n');
}

void output_result_5(char ch, char *str, int result, int test) {
    printf("%s\n%c\n", str, ch);
    if (result == test) {
        printf("SUCCESS");
    } else
        printf("FAIL");
}

void s21_strstr_test() {
    char str11[] = "1234567";
    char str21[] = "345";
    char test[] = "34567";
    output_result_6(str21, str11, s21_strstr(str11, str21), test);
    printf("%c", '\n');
    char str12[] = "yhyhhhhh";
    char str22[] = "h";
    char test2[] = "yhhhhh";
    output_result_6(str22, str12, s21_strstr(str12, str22), test2);
    printf("%c", '\n');
    char str13[] = "444445";
    char str23[] = "5";
    char test3[] = "\0";
    output_result_6(str23, str13, s21_strstr(str13, str23), test3);
}

void output_result_6(char *str2, char *str, char *result, char *test) {
    printf("%s\n%s\n", str, str2);
    if (s21_strcmp(result, test) == 0) {
        printf("SUCCESS");
    } else
        printf("FAIL");
}