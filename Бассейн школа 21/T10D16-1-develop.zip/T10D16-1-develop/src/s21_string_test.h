#ifndef S21_STRING_TEST_H
#define S21_STRING_TEST_H

void s21_strlen_test();
void otput_result_1(char *str, int result, int test);
void s21_strcmp_test();
void otput_result_2(char *str1, char *str2, int result, int test);
void s21_strcpy_test();
void output_result_3(char *str_print, char *str, char *result, char *test);
void s21_strcat_test();
void output_result_4(char *str_print, char *str, char *result, char *test);
void s21_strchr_test();
void output_result_5(char ch, char *str, int result, int test);
void s21_strstr_test();
void output_result_6(char *str2, char *str, char *result, char *test);

#endif