#ifndef S21_STRING_H
#define S21_STRING_H

int s21_strlen(const char *str);
int s21_strcmp(char *str1, char *str2);
char *s21_strcpy(char *str2, const char *str1);
char *s21_strcat(char *str1, char *str2);
int s21_strchr(char *str, char ch);
int compare(const char *str1, const char *str2);
char *s21_strstr(char *str1, char *str2);

#endif