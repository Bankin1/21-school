#include "bst.h"

#include <stdio.h>
#include <stdlib.h>

t_btree *bstree_create_node(int item) {
    t_btree *tmp = malloc(sizeof(t_btree));
    tmp->item = item;               // Присваивание значения ключу
    tmp->left = tmp->right = NULL;  // Присваивание указателю на левое и правое поддерево значения NULL
    return tmp;
}