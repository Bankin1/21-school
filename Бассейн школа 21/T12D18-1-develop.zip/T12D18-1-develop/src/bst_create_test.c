#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

int main() {
    for (int i = 0; i < 4; i++) {
        printf("test %i:\n", i);
        t_btree *tree = bstree_create_node(i);
        printf("key of node: %i, left node : %p, right : %p\n", tree->item, tree->left, tree->right);
        if (tree->item == i) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        free(tree);
    }
    return 0;
}
