#include <stdio.h>
#include <string.h>
struct my_struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int get_file_size_in_bytes(FILE *pfile);
void swap_records_in_file(FILE *pfile, int record_index1, int record_index2);
void write_record_in_file(FILE *pfile, const struct my_struct *record_to_write, int index);
struct my_struct read_record_from_file(FILE *pfile, int index);
int get_records_count_in_file(FILE *pfile);
int init_file(FILE **file, char *filename);
void output_result(FILE *file);
int sravnen(struct my_struct first, struct my_struct secend);
void sort(FILE *file);
void add_struct(FILE *file);

int main() {
    char name_of_file1[1234];
    scanf("%s", name_of_file1);
    char name_of_file[234] = "../";
    strcat(name_of_file, name_of_file1);
    FILE *file;
    int n;
    if (init_file(&file, name_of_file)) {
        if (scanf("%d", &n) && getchar() == '\n') {
            switch (n) {
                case 0:
                    output_result(file);
                    break;
                case 1:
                    sort(file);
                    output_result(file);
                    break;
                case 2:
                    add_struct(file);
                    sort(file);
                    output_result(file);
                    break;
                default:
                    printf("n/a");
                    break;
            }
        } else
            printf("n/a");
    } else
        printf("n/a");
    fclose(file);
    return 0;
}

void add_struct(FILE *file) {
    struct my_struct print;
    if (scanf("%d %d %d %d %d %d %d %d", &print.year, &print.month, &print.day, &print.hour, &print.minute,
              &print.second, &print.status, &print.code) == 8 &&
        getchar() == '\n') {
        write_record_in_file(file, &print, get_records_count_in_file(file));
    } else
        printf("n/a");
}

int sravnen(struct my_struct first, struct my_struct secend) {
    int res = 0;
    if (first.year > secend.year) {
        res = 1;
    } else if (first.year == secend.year) {
        if (first.month > secend.month) {
            res = 1;
        } else if (first.month == secend.month) {
            if (first.day > secend.day) {
                res = 1;
            } else if (first.day == secend.day) {
                if (first.hour > secend.hour) {
                    res = 1;
                } else if (first.hour == secend.hour) {
                    if (first.minute > secend.minute) {
                        res = 1;
                    } else if (first.minute == secend.minute) {
                        if (first.second > secend.second) {
                            res = 1;
                        }
                    }
                }
            }
        }
    }
    return res;
}

void sort(FILE *file) {
    for (int i = 0; i < get_records_count_in_file(file) - 1; i++) {
        for (int j = i + 1; j < get_records_count_in_file(file); j++) {
            if (sravnen(read_record_from_file(file, i), read_record_from_file(file, j))) {
                swap_records_in_file(file, i, j);
            }
        }
    }
}

void output_result(FILE *file) {
    for (int i = 0; i < get_records_count_in_file(file); i++) {
        struct my_struct print = read_record_from_file(file, i);
        if (i < get_records_count_in_file(file) - 1) {
            printf("%d %d %d %d %d %d %d %d\n", print.year, print.month, print.day, print.hour, print.minute,
                   print.second, print.status, print.code);
        } else
            printf("%d %d %d %d %d %d %d %d", print.year, print.month, print.day, print.hour, print.minute,
                   print.second, print.status, print.code);
    }
}

int init_file(FILE **file, char *filename) {
    int error = 1;
    *file = fopen(filename, "rb+");
    if (*file != NULL) {
        fseek(*file, 0, SEEK_END);
        long size = ftell(*file);
        if (size == 0) {
            error = 0;
        }
        fseek(*file, 0, SEEK_SET);
    } else
        error = 0;
    return error;
}

// Function of reading a record of a given type from a file by its serial number.
struct my_struct read_record_from_file(FILE *pfile, int index) {
    // Calculation of the offset at which desired entry should be located from the beginning of the file.
    int offset = index * sizeof(struct my_struct);
    // Move the position pointer to the calculated offset from the beginning of the file.
    fseek(pfile, offset, SEEK_SET);

    // Reading a record of the specified type from a file.
    struct my_struct record;
    fread(&record, sizeof(struct my_struct), 1, pfile);

    // For safety reasons, we return the file position pointer to the beginning of the file.
    rewind(pfile);

    // Return read record
    return record;
}

// Function of writing a record of the specified type to the file at the specified serial number.
void write_record_in_file(FILE *pfile, const struct my_struct *record_to_write, int index) {
    // Calculation of the offset at which the required record should be located from the beginning of the
    // file.
    int offset = index * sizeof(struct my_struct);
    // Move the position pointer to the calculated offset from the beginning of the file.
    fseek(pfile, offset, SEEK_SET);

    // Write a record of the specified type to a file.
    fwrite(record_to_write, sizeof(struct my_struct), 1, pfile);

    // Just in case, force the I/O subsystem to write the contents of its buffer to a file right now.
    fflush(pfile);

    // For safety reasons, return the file position pointer to the beginning of the file.
    rewind(pfile);
}

// Function of mutual transfer of two records in the file by their indexes.
void swap_records_in_file(FILE *pfile, int record_index1, int record_index2) {
    // Read both records from file to variables
    struct my_struct record1 = read_record_from_file(pfile, record_index1);
    struct my_struct record2 = read_record_from_file(pfile, record_index2);

    // Rewrite records in file
    write_record_in_file(pfile, &record1, record_index2);
    write_record_in_file(pfile, &record2, record_index1);
}

// Function to get file size in bytes.
int get_file_size_in_bytes(FILE *pfile) {
    int size = 0;
    fseek(pfile, 0, SEEK_END);  // Move the position pointer to the end of the file.
    size = ftell(
        pfile);  // Read the number of bytes from the beginning of the file to the current position pointer.
    rewind(pfile);  // For safety reasons, move the position pointer back to the beginning of the file.
    return size;
}

// Function to get count of records in file
int get_records_count_in_file(FILE *pfile) {
    return get_file_size_in_bytes(pfile) / sizeof(struct my_struct);
}
