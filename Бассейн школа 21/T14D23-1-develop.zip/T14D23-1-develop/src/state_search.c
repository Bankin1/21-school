#include <stdio.h>
#include <string.h>
struct my_struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int get_file_size_in_bytes(FILE *pfile);
struct my_struct read_record_from_file(FILE *pfile, int index);
int get_records_count_in_file(FILE *pfile);
int init_file(FILE **file, char *filename);
void find_struct(FILE *file, struct my_struct find);

int main() {
    char name_of_file1[1234];
    scanf("%s", name_of_file1);
    char name_of_file[234] = "../";
    strcat(name_of_file, name_of_file1);
    FILE *file;
    if (init_file(&file, name_of_file)) {
        struct my_struct find;
        if (scanf("%d.%d.%d", &find.day, &find.month, &find.year)) {
            find_struct(file, find);
        } else
            printf("n/a");
    } else
        printf("n/a");
    fclose(file);
    return 0;
}

void find_struct(FILE *file, struct my_struct find) {
    int flag = 0;
    struct my_struct res;
    for (int i = 0; i < get_records_count_in_file(file); i++) {
        struct my_struct check = read_record_from_file(file, i);
        if (check.year == find.year && check.month == find.month && check.day == find.day) {
            if (flag == 0) {
                res = check;
                flag = 1;
            }
        }
    }
    if (flag == 1) {
        printf("%d", res.code);
    } else
        printf("n/a");
}

int init_file(FILE **file, char *filename) {
    int error = 1;
    *file = fopen(filename, "rb+");
    if (*file != NULL) {
        fseek(*file, 0, SEEK_END);
        long size = ftell(*file);
        if (size == 0) {
            error = 0;
        }
        fseek(*file, 0, SEEK_SET);
    } else
        error = 0;
    return error;
}

// Function of reading a record of a given type from a file by its serial number.
struct my_struct read_record_from_file(FILE *pfile, int index) {
    // Calculation of the offset at which desired entry should be located from the beginning of the file.
    int offset = index * sizeof(struct my_struct);
    // Move the position pointer to the calculated offset from the beginning of the file.
    fseek(pfile, offset, SEEK_SET);

    // Reading a record of the specified type from a file.
    struct my_struct record;
    fread(&record, sizeof(struct my_struct), 1, pfile);

    // For safety reasons, we return the file position pointer to the beginning of the file.
    rewind(pfile);

    // Return read record
    return record;
}

// Function to get file size in bytes.
int get_file_size_in_bytes(FILE *pfile) {
    int size = 0;
    fseek(pfile, 0, SEEK_END);  // Move the position pointer to the end of the file.
    size = ftell(
        pfile);  // Read the number of bytes from the beginning of the file to the current position pointer.
    rewind(pfile);  // For safety reasons, move the position pointer back to the beginning of the file.
    return size;
}

// Function to get count of records in file
int get_records_count_in_file(FILE *pfile) {
    return get_file_size_in_bytes(pfile) / sizeof(struct my_struct);
}
