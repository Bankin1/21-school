#include <stdio.h>
#include <string.h>
#include <unistd.h>

struct my_struct {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int get_file_size_in_bytes(FILE *pfile);
void write_record_in_file(FILE *pfile, const struct my_struct *record_to_write, int index);
struct my_struct read_record_from_file(FILE *pfile, int index);
int get_records_count_in_file(FILE *pfile);
int init_file(FILE **file, char *filename);
void output_result(FILE *file);
int sravnen(struct my_struct first, struct my_struct secend);
int ravno(struct my_struct first, struct my_struct secend);
void delit(FILE *file, struct my_struct start, struct my_struct end, char *name_of_file);

int main() {
    char name_of_file1[1234];
    scanf("%s", name_of_file1);
    char name_of_file[234] = "../";
    strcat(name_of_file, name_of_file1);
    FILE *file;
    if (init_file(&file, name_of_file)) {
        struct my_struct start;
        struct my_struct end;
        if (scanf("%d.%d.%d %d.%d.%d", &start.day, &start.month, &start.year, &end.day, &end.month,
                  &end.year) == 6 &&
            getchar() == '\n') {
            if (sravnen(end, start)) {
                delit(file, start, end, name_of_file);
            } else
                printf("n/a");
        } else
            printf("n/a");
    } else
        printf("n/a");
    fclose(file);
    return 0;
}

void delit(FILE *file, struct my_struct start, struct my_struct end, char *name_of_file) {
    int index = 0;
    FILE *tmp = fopen("tmp", "wb+");
    for (int i = 0; i < get_records_count_in_file(file); i++) {
        struct my_struct record = read_record_from_file(file, i);
        if ((!ravno(start, record) && sravnen(start, record)) || sravnen(record, end)) {
            write_record_in_file(tmp, &record, index);
            index++;
        }
    }
    fclose(file);
    fclose(tmp);
    remove(name_of_file);
    rename("tmp", name_of_file);
    file = fopen(name_of_file, "rb+");
    output_result(file);
    fclose(file);
}

int ravno(struct my_struct first, struct my_struct secend) {
    return (first.year == secend.year && first.month == secend.month && first.day == secend.day);
}

int sravnen(struct my_struct first, struct my_struct secend) {
    int res = 0;
    if (first.year > secend.year) {
        res = 1;
    } else if (first.year == secend.year) {
        if (first.month > secend.month) {
            res = 1;
        } else if (first.month == secend.month) {
            if (first.day > secend.day) {
                res = 1;
            }
        }
    }
    return res;
}

void output_result(FILE *file) {
    for (int i = 0; i < get_records_count_in_file(file); i++) {
        struct my_struct print = read_record_from_file(file, i);
        if (i < get_records_count_in_file(file) - 1) {
            printf("%d %d %d %d %d %d %d %d\n", print.year, print.month, print.day, print.hour, print.minute,
                   print.second, print.status, print.code);
        } else
            printf("%d %d %d %d %d %d %d %d", print.year, print.month, print.day, print.hour, print.minute,
                   print.second, print.status, print.code);
    }
}

int init_file(FILE **file, char *filename) {
    int error = 1;
    *file = fopen(filename, "rb+");
    if (*file != NULL) {
        fseek(*file, 0, SEEK_END);
        long size = ftell(*file);
        if (size == 0) {
            error = 0;
            fclose(*file);
        }
        fseek(*file, 0, SEEK_SET);
    } else {
        error = 0;
        fclose(*file);
    }
    return error;
}

// Function of reading a record of a given type from a file by its serial number.
struct my_struct read_record_from_file(FILE *pfile, int index) {
    // Calculation of the offset at which desired entry should be located from the beginning of the file.
    int offset = index * sizeof(struct my_struct);
    // Move the position pointer to the calculated offset from the beginning of the file.
    fseek(pfile, offset, SEEK_SET);

    // Reading a record of the specified type from a file.
    struct my_struct record;
    fread(&record, sizeof(struct my_struct), 1, pfile);

    // For safety reasons, we return the file position pointer to the beginning of the file.
    rewind(pfile);

    // Return read record
    return record;
}

// Function of writing a record of the specified type to the file at the specified serial number.
void write_record_in_file(FILE *pfile, const struct my_struct *record_to_write, int index) {
    // Calculation of the offset at which the required record should be located from the beginning of the
    // file.
    int offset = index * sizeof(struct my_struct);
    // Move the position pointer to the calculated offset from the beginning of the file.
    fseek(pfile, offset, SEEK_SET);

    // Write a record of the specified type to a file.
    fwrite(record_to_write, sizeof(struct my_struct), 1, pfile);

    // Just in case, force the I/O subsystem to write the contents of its buffer to a file right now.
    fflush(pfile);

    // For safety reasons, return the file position pointer to the beginning of the file.
    rewind(pfile);
}

// Function to get file size in bytes.
int get_file_size_in_bytes(FILE *pfile) {
    int size = 0;
    fseek(pfile, 0, SEEK_END);  // Move the position pointer to the end of the file.
    size = ftell(
        pfile);  // Read the number of bytes from the beginning of the file to the current position pointer.
    rewind(pfile);  // For safety reasons, move the position pointer back to the beginning of the file.
    return size;
}

// Function to get count of records in file
int get_records_count_in_file(FILE *pfile) {
    return get_file_size_in_bytes(pfile) / sizeof(struct my_struct);
}
// printf("%d %d %d %d %d %d %d %d\n", record.year, record.month, record.day, record.hour, record.minute,
//                    record.second, record.status, record.code);