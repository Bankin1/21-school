#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

#include "stack_test.h"

int main() { push_and_pop_test(); }

void push_and_pop_test() {
    int data[] = {12, 13, 34};
    struct node* doors = init(data[0]);
    push(&doors, data[1]);
    push(&doors, data[2]);
    int count = 0;
    for (int i = 2; i != -1; i--) {
        int popi = (pop(&doors));
        if (popi == data[i]) {
            printf("%d \n", popi);
            count++;
        }
    }
    if (count == 3)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    destroy(&doors);
}