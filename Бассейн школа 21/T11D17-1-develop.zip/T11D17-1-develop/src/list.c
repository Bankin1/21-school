#include "list.h"

#include <stdio.h>
#include <stdlib.h>

struct node* init(const struct door* door) {
    struct node* elem = (struct node*)malloc(sizeof(struct node));
    elem->data = *door;
    elem->next = NULL;
    return elem;
}

struct node* add_door(struct node* elem, struct door* door) {
    struct node* new_element = init(door);
    new_element->next = elem->next;
    elem->next = new_element;
    return new_element;
}

struct node* find_door(int door_id, struct node* root) {
    struct node* tmp = root;
    while (tmp->next != NULL) {
        if (tmp->data.id == door_id) {
            return tmp;
        }
        tmp = tmp->next;
    }
    return tmp;
}

struct node* remove_door(struct node* elem, struct node** root) {
    struct node* tmp = *root;
    if (*root == elem) {
        tmp = (*root)->next;
        free(*root);
        *root = tmp;
    } else {
        for (; tmp->next != NULL; tmp = tmp->next) {
            if (tmp->next == elem) {
                struct node* buf = elem->next;
                free(tmp->next);
                tmp->next = buf;
                return tmp;
            }
        }
    }
    return tmp;
}

void destroy(struct node** root) {
    struct node* pr = *root;
    while (*root) {
        *root = (*root)->next;
        free(pr);
        pr = *root;
    }
}