#ifndef STACK_TEST_H
#define STACK_TEST_H

void push_and_pop_test();
#endif