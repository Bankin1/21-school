#include "list.h"

#include <stdio.h>
#include <stdlib.h>

#include "list_test.h"

int main() {
    add_door_test();
    remove_door_test();
}

void add_door_test() {
    struct door data[] = {{12, 0}, {13, 1}, {34, 0}};
    struct node* doors = init(&data[0]);
    struct node* root = doors;
    doors = add_door(doors, &data[1]);
    add_door(doors, &data[2]);
    struct node* tmp = root;
    int count = 0;
    for (int i = 0; i < 3; i++) {
        if (tmp->data.id == data[i].id && tmp->data.status == data[i].status) {
            printf("%d %d\n", tmp->data.id, tmp->data.status);
            count++;
        }
        tmp = tmp->next;
    }
    if (count == 3)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    destroy(&root);
}

void remove_door_test() {
    struct door data[] = {{12, 0}, {13, 1}, {34, 0}};
    struct door data_test[] = {{12, 0}, {34, 0}};
    struct node* doors2 = init(&data[0]);
    struct node* root2 = doors2;
    doors2 = add_door(doors2, &data[1]);
    add_door(doors2, &data[2]);
    remove_door(find_door(13, root2), &root2);
    struct node* tmp = root2;
    int count = 0;
    for (int i = 0; i < 2; i++) {
        if (tmp->data.id == data_test[i].id && tmp->data.status == data_test[i].status) {
            printf("%d %d\n", tmp->data.id, tmp->data.status);
            count++;
        }
        tmp = tmp->next;
    }
    if (count == 2)
        printf("SUCCESS");
    else
        printf("FAIL");
    destroy(&root2);
}