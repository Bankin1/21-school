#ifndef LIST_TEST_H
#define LIST_TEST_H

void add_door_test();
void remove_door_test();
#endif