#ifndef STACK_H
#define STACK_H

struct node {
    int data;
    struct node* next;
};

struct node* init(int data);
int pop(struct node** stack);
void push(struct node** stack, int data);
void destroy(struct node** stack);

#endif