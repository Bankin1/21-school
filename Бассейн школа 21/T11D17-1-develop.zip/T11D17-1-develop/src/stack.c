#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

struct node* init(int data) {
    struct node* stack = (struct node*)malloc(sizeof(struct node));
    stack->data = data;
    stack->next = NULL;
    return stack;
}

int pop(struct node** stack) {
    struct node* res = *stack;
    *stack = (*stack)->next;
    int pop_res = res->data;
    free(res);
    return pop_res;
}

void push(struct node** stack, int data) {
    struct node* new_elem = init(data);
    new_elem->next = *stack;
    *stack = new_elem;
}

void destroy(struct node** stack) {
    struct node* pr = *stack;
    while (*stack) {
        *stack = (*stack)->next;
        free(pr);
        pr = *stack;
    }
}