#include <ncurses.h>
#include <stdlib.h>
#include <unistd.h>

#define WIDTH 80
#define HEIGHT 25

void generate(int **data);
int **init_matrix();
void free_matrix(int **matrix);
int read_matrix(int **data);

int count_n(int **data, int i, int j);
void switch_check(int **data);
void print_space(int **data);

int main() {
    initscr();
    noecho();
    curs_set(FALSE);
    nodelay(stdscr, TRUE);
    int **data = init_matrix();
    if (read_matrix(data) == 0) {
        generate(data);
    }
    if (freopen("/dev/tty", "r", stdin) != NULL) {
        print_space(data);
        char *mesg = "Press 'q' to exit, '+' to speed up, '-' to speed down";
        mvwprintw(stdscr, 25, 0, "%s", mesg);
        int time = 100000;
        while (1) {
            refresh();
            usleep(time);
            switch_check(data);
            print_space(data);
            int ch = getch();
            if (ch == '-' && time < 500000) {
                time += 10000;
            }
            if (ch == '+' && time > 10000) {
                time -= 10000;
            }
            if (ch == 'Q' || ch == 'q') break;
        }
    }
    free_matrix(data);
    endwin();
    return 1;
}

int read_matrix(int **data) {
    int counter = 0;
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (scanf("%d", &data[i][j]) == 1) {
                counter += 1;
            }
        }
    }
    return counter;
}

void switch_check(int **data) {
    int tmp[HEIGHT][WIDTH];
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (((count_n(data, i, j) == 2 || count_n(data, i, j) == 3) && data[i][j] == 1) ||
                (count_n(data, i, j) == 3 && data[i][j] == 0))
                tmp[i][j] = 1;
            else
                tmp[i][j] = 0;
        }
    }
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            data[i][j] = tmp[i][j];
        }
    }
}

void print_space(int **data) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (data[i][j] == 1)
                mvaddch(i, j, '@');
            else
                mvaddch(i, j, '.');
        }
    }
    refresh();
}

int count_n(int **data, int i, int j) {
    int count_neighbour = 0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            count_neighbour += data[(i + x + HEIGHT) % HEIGHT][(j + y + WIDTH) % WIDTH];
        }
    }
    count_neighbour -= data[i][j];
    return count_neighbour;
}

void free_matrix(int **matrix) {
    for (int i = 0; i < HEIGHT; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

int **init_matrix() {
    int **matrix = NULL;
    matrix = (int **)malloc(HEIGHT * sizeof(int *));
    for (int i = 0; i < HEIGHT; i++) {
        matrix[i] = (int *)malloc(WIDTH * sizeof(int));
    }
    return matrix;
}

void generate(int **data) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            data[i][j] = rand() % 2;
        }
    }
}