#include <stdio.h>

void sort(int *a);
int input(int *a);
void output(int *a);

int main() {
    int data[10];
    if (input(data)) {
        sort(data);
        output(data);
    } else
        printf("n/a");
    return 0;
}

int input(int *a) {
    int k;
    for (int i = 0; i < 10; i++) {
        if (scanf("%d", &a[i]) == 1 && getchar() == '\n') {
            k = 1;
        } else
            k = 0;
    }
    return k;
}

void sort(int *a) {
    int tmp;
    for (int i = 0; i < 9; i++) {
        for (int j = i + 1; j < 10; j++) {
            if (a[i] > a[j]) {
                tmp = a[j];
                a[j] = a[i];
                a[i] = tmp;
            }
        }
    }
}

void output(int *a) {
    for (int b = 0; b < 10; b++) {
        if (b == 10 - 1)
            printf("%d", a[b]);
        else
            printf("%d ", a[b]);
    }
}
