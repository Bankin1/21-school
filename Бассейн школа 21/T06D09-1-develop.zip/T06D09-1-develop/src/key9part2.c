#include <stdio.h>

#define LEN 100

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length, int *result1,
         int *result_length1);
void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
void copy_array(int *data1, int *data2);
int input(int *buff, int *length);
void output(int *a, int len);
void revers(int *data, int len);
void for_sum(int *data1, int len1, int *data2, int len2, int *result, int *result_length);

/*
    Беззнаковая целочисленная длинная арифметика
    с использованием массивов.
    Ввод:
     * 2 длинных числа в виде массивов до 100 элементов
     * В один элемент массива нельзя вводить число > 9
    Вывод:
     * Результат сложения и разности чисел-массивов
    Пример:
     * 1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 6 1
       2 9

       1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 9 0
       1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 3 2
*/
int main() {
    int len1 = 0, data1[LEN], len2 = 0, data2[LEN], res_sum[LEN + 1], len_res_sum = 0;
    int res_sub[LEN], len_res_sub = 0, res_sum1[LEN + 1], len_res_sum1 = 0;
    if (input(data1, &len1) && input(data2, &len2)) {  //заполняем массивы
        sum(data1, len1, data2, len2, res_sum, &len_res_sum, res_sum1, &len_res_sum1);
        sub(data1, len1, data2, len2, res_sub, &len_res_sub);
        output(res_sum, len_res_sum);
        output(res_sum1, len_res_sum1);
        if (len_res_sub != 123) {
            output(res_sub, len_res_sub);
        } else {
            printf("n/a\n");
        }
    } else
        printf("n/a\n");
}

void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length) {
    int data1[LEN], data2[LEN], mean = 0;
    copy_array(buff1, data1);
    copy_array(buff2, data2);
    revers(data1, len1);
    revers(data2, len2);
    if (len1 >= len2) {
        for (int i = 0; i < len1; i++) {
            if (i < len2) {
                if (data1[i] - mean < data2[i]) {
                    result[i] = 10 + data1[i] - mean - data2[i];
                    mean = 1;
                    (*result_length)++;
                } else {
                    result[i] = data1[i] - mean - data2[i];
                    mean = 0;
                    (*result_length)++;
                }
            } else {
                result[i] = data1[i] - mean;
                mean = 0;
                (*result_length)++;
            }
        }
    } else
        (*result_length) = 123;
    revers(result, *result_length);
}

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length, int *result1,
         int *result_length1) {
    int data1[LEN], data2[LEN];
    copy_array(buff1, data1);
    copy_array(buff2, data2);
    revers(data1, len1);
    revers(data2, len2);
    if (len1 >= len2) {
        for_sum(data1, len1, data2, len2, result, result_length);
    } else {
        for_sum(data2, len2, data1, len1, result1, result_length1);
    }
    revers(result, *result_length);
    revers(result1, *result_length1);
}

void for_sum(int *data1, int len1, int *data2, int len2, int *result, int *result_length) {
    int mean = 0;
    for (int i = 0; i < len1; i++) {
        if (i < len2) {
            result[i] = (data1[i] + data2[i] + mean) % 10;
            mean = (data1[i] + data2[i] + mean) / 10;
            (*result_length)++;
        } else {
            result[i] = (data1[i] + mean) % 10;
            mean = (data1[i] + mean) / 10;
            (*result_length)++;
        }
    }
}

int input(int *buff, int *length) {
    int err_input = 1, count = 0;
    char ch;
    do {
        if (scanf("%d", &buff[*length])) {
            count++;
            ch = getchar();
            if ((ch != '\n' && ch != ' ') || buff[*length] < 0 || buff[*length] > 9 || count > LEN) {
                err_input = 0;
            } else {
                (*length)++;
            }
        } else {
            err_input = 0;
        }
        if (err_input == 0) {
            break;
        }
    } while (ch != '\n');
    return err_input;
}

void output(int *a, int len) {
    int b = 0;
    for (b = 0; b < len; b++) {
        if (b == len - 1)
            printf("%d\n", a[b]);
        else
            printf("%d ", a[b]);
    }
}

void copy_array(int *data1, int *data2) {
    for (int i = 0; i < LEN; i++) {
        data2[i] = data1[i];
    }
}

void revers(int *data, int len) {
    int tmp;
    for (int i = 0; i < len / 2; i++) {
        tmp = data[i];
        data[i] = data[len - 1 - i];
        data[len - 1 - i] = tmp;
    }
}