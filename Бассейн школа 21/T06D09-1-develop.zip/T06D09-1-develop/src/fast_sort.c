#include <stdio.h>
#define N 10
void quickSort(int *numbers, int left, int right);
int input(int *a);
void output(int *a);
void sort(int *a);
void copy_array(int *data1, int *data2);

int main() {
    int data[N], data2[N];
    if (input(data)) {
        copy_array(data, data2);
        sort(data);
        quickSort(data2, 0, N - 1);
        output(data);
        output(data2);
    } else
        printf("n/a");
    return 0;
}

int input(int *a) {
    int k;
    for (int i = 0; i < 10; i++) {
        if (scanf("%d", &a[i]) == 1 && getchar() == '\n') {
            k = 1;
        } else
            k = 0;
    }
    return k;
}

void quickSort(int *numbers, int left, int right) {
    int pivot;
    int l_hold = left;
    int r_hold = right;
    pivot = numbers[left];
    while (left < right) {
        while ((numbers[right] >= pivot) && (left < right)) right--;
        if (left != right) {
            numbers[left] = numbers[right];
            left++;
        }
        while ((numbers[left] <= pivot) && (left < right)) left++;
        if (left != right) {
            numbers[right] = numbers[left];
            right--;
        }
    }
    numbers[left] = pivot;
    pivot = left;
    left = l_hold;
    right = r_hold;
    if (left < pivot) quickSort(numbers, left, pivot - 1);
    if (right > pivot) quickSort(numbers, pivot + 1, right);
}

void sort(int *a) {
    int tmp;
    for (int i = 0; i < 9; i++) {
        for (int j = i + 1; j < 10; j++) {
            if (a[i] > a[j]) {
                tmp = a[j];
                a[j] = a[i];
                a[i] = tmp;
            }
        }
    }
}

void output(int *a) {
    for (int b = 0; b < 10; b++) {
        if (b == 10 - 1)
            printf("%d\n", a[b]);
        else
            printf("%d ", a[b]);
    }
}
void copy_array(int *data1, int *data2) {
    for (int i = 0; i < N; i++) {
        data2[i] = data1[i];
    }
}