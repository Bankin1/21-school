/*------------------------------------
        Здравствуй, человек!
        Чтобы получить ключ
        поработай с комментариями.
-------------------------------------*/

#include <stdio.h>
#define NMAX 10

int input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
void find_numbers(int *buffer, int length, int number, int *numbers, int *k);

/*------------------------------------
        Функция получает массив данных
        через stdin.
        Выдает в stdout особую сумму
        и сформированный массив
        специальных элементов
        (выбранных с помощью найденной суммы):
        это и будет частью ключа
-------------------------------------*/
int main() {
    int k = 0;
    int n = 0, data[NMAX], data_res[NMAX];
    if (input(data, &n)) {
        int num = sum_numbers(data, n);
        printf("%d\n", num);
        find_numbers(data, n, num, data_res, &k);
        output(data_res, k);
    } else
        printf("n/a");
    return 0;
}

void output(int *buffer, int length) {
    for (int b = 0; b < length; b++) {
        if (b == length - 1)
            printf("%d", buffer[b]);
        else
            printf("%d ", buffer[b]);
    }
}

int input(int *buffer, int *length) {
    int k = 1;
    if (scanf("%d", length) == 1 && getchar() == '\n' && (*length) <= NMAX && (*length) > 0) {
        for (int b = 0; b < (*length); b++) {
            if (scanf("%d", &buffer[b]) == 1 && getchar() == '\n') {
                k = 1;
            } else
                k = 0;
        }

    } else
        k = 0;
    return k;
}

/*------------------------------------
        Функция должна находить
        сумму четных элементов
        с 0-й позиции.
-------------------------------------*/
int sum_numbers(int *buffer, int length) {
    int sum = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] % 2 == 0) {
            sum = sum + buffer[i];
        }
    }
    return sum;
}

/*------------------------------------
        Функция должна находить
        все элементы, на которые нацело
        делится переданное число и
        записывает их в выходной массив.
-------------------------------------*/
void find_numbers(int *buffer, int length, int number, int *numbers, int *k) {
    for (int i = 0; i < length; i++) {
        if (buffer[i] != 0 && number % buffer[i] == 0) {
            numbers[*k] += buffer[i];
            (*k)++;
        }
    }
}
