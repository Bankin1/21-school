#include <math.h>
#include <stdio.h>
#define NMAX 10

int input(int *buffer, int *length);
void output(int *buffer, int length);
void chenge(int *a, int n, int k);

int main() {
    int k = 0;
    int n = 0, data[NMAX];
    if (input(data, &n)) {
        if (scanf("%d", &k) == 1 && getchar() == '\n') {
            chenge(data, n, k);
            output(data, n);
        } else
            printf("n/a");
    } else
        printf("n/a");
    return 0;
}

void chenge(int *a, int n, int k) {
    int chenge[n];
    k %= n;
    for (int j = 0; j < n; j++) {
        chenge[(j - k + n) % n] = a[j];
    }
    for (int i = 0; i < n; i++) {
        a[i] = chenge[i];
    }
}

void output(int *buffer, int length) {
    for (int b = 0; b < length; b++) {
        if (b == length - 1)
            printf("%d", buffer[b]);
        else
            printf("%d ", buffer[b]);
    }
}

int input(int *buffer, int *length) {
    int k = 1;
    if (scanf("%d", length) == 1 && getchar() == '\n' && (*length) <= NMAX && (*length) > 0) {
        for (int b = 0; b < (*length); b++) {
            if (scanf("%d", &buffer[b]) == 1 && getchar() == '\n') {
                k = 1;
            } else
                k = 0;
        }
    } else
        k = 0;
    return k;
}