/*
    Search module for the desired value from data array.

    Returned value must be:
        - "even"
        - ">= mean"
        - "<= mean + 3 * sqrt(variance)"
        - "!= 0"

        OR

        0
*/
#include <math.h>
#include <stdio.h>
#define NMAX 30

int input(int *a, int *n);
double mean(int *a, int n);
double variance(int *a, int n);
int output_result(int *a, int n);

int main() {
    int n = 0, data[NMAX];
    if (input(data, &n)) {
        printf("%d", output_result(data, n));
        return 0;
    } else
        printf("n/a");
    return 0;
}

int input(int *a, int *n) {
    int k = 1;
    if (scanf("%d", n) == 1 && getchar() == '\n' && (*n) <= NMAX && *n != 0) {
        for (int b = 0; b < (*n); b++) {
            if (scanf("%d", &a[b]) == 1 && getchar() == '\n') {
                k = 1;
            } else
                k = 0;
        }

    } else
        k = 0;
    return k;
}

double mean(int *a, int n) {
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
    return sum / n;
}

double variance(int *a, int n) {
    double sum = 0, dsum = 0;
    for (int i = 0; i < n; i++) {
        dsum += a[i] * a[i];
    }
    sum = mean(a, n) * mean(a, n);
    return dsum / n - sum;
}

int output_result(int *a, int n) {
    int res = 0;
    double mean_res, three_sigm;
    mean_res = mean(a, n);
    three_sigm = sqrt(variance(a, n)) * 3.0;
    for (int i = 0; i < n; i++) {
        if (a[i] != 0 && a[i] % 2 == 0 && a[i] <= mean_res + three_sigm && a[i] >= mean_res) {
            res = a[i];
            break;
        }
    }
    return res;
}
